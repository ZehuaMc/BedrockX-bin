function u_k(name)
GUI(name,"a",L("getMoney",name),L("getMoney",name))
end
function onJoin(name)

end
function onChat(name,chat)

end
function onCMD(name,cmd)

end
function onPlayerKillMob(name,typeid)

end

